this builds a toy of VIB results type




